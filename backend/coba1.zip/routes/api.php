<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InspectionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/inspections', [InspectionController::class, 'index']);

// Create a new inspection
Route::post('/inspections', [InspectionController::class, 'store']);

// Display a specific inspection
Route::get('/inspections/{inspection}', [InspectionController::class, 'show']);

// Update an existing inspection
Route::put('/inspections/{inspection}', [InspectionController::class, 'update']);

// Delete an inspection
Route::delete('/inspections/{inspection}', [InspectionController::class, 'destroy']);